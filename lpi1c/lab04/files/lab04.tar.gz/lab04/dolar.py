#!/usr/bin/python3
# -*- coding: utf-8 -*-
#
"""
Get the exchange rate for Dolar, Euro and Bitcoin
"""

__author__ = "Frederico Freire Boaventura"


# Imports
import requests
from bs4 import BeautifulSoup


def dolar():
    """
    Get the Dolar and Euro exchange rates
    """
    data = []
    url = 'https://www.dolarhoje.net.br/'
    try:
        response = requests.get(url)
        # Parse the HTML page
        soup = BeautifulSoup(response.text, 'html.parser')
        # Identify and recover the table that holds the exchange rates
        table = soup.find('div', id='divSpdInText')
        # Filter out all the lines of the table
        rows = table.findAll('tr')
        for row in rows:
            # Split the lines into columns
            cols = row.find_all('td')
            cols = [rate.text.strip() for rate in cols]
            # Add to the data dicionary the exchange rates found
            data.append([rate for rate in cols if rate])

        return data
    except requests.ConnectionError:
        return False

def main():
    dolar_rate = dolar()
    if dolar_rate:
        for exchange in dolar_rate:
            if len(exchange) > 1:
                print(f'{exchange[0]}: {exchange[1]}')
    else:
        print('Error trying to reach the data server')

# Main body
if __name__ == '__main__':
    main()
